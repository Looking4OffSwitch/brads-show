# Creative Prompt

Use this file to describe your sketch idea. The more specific you are, the better the results—but you can also keep it loose if you want to be surprised by the pitches.

---

## Core Idea (Required)

A group of high school aged teenagers growing up 1984-1988. The group of friends are constantly making bad decisions. But, they always seem to end up okay in the end.

### What Sparked This
All of these stories are based on real events.

---

## Specific Requirements (Optional)

- NA

### Must Include
List specific moments, lines, jokes, or elements you definitely want in this sketch

- Brad is at Reed's house helping Reed change the oil in his car. It's a mustang that is only 4 cylenders. They drain the oil without first getting a filter and oil. So, they borrow Reeds' gtandmother's AMC Spirit to go to the store. She says ok ot borrowing her car but says "don't go too far". Reed lives in a house in Mountain Lake, NJ. On the way back from the store, Reed is driving on a dirt road. There is a "ramp" created by a rain washout. Brad says to Reed "hit that jump". Reed says "ok". Brad says "floor it". Reed says "I am". They are not going very fast because it is an AMC Spirit. When they hit the ramp. The car gets a little air, or maybe it just feels that way. When they hit the ground, the transmission slams into the dirt road and breaks from the car. Also, ashes or somthing poof from the ashtray where Reed and Brad think it is smoke. Reed and Brad get out to inspect the vehcile and stand staring at it for a bit. They laugh and talk as they walk the rest of the way back to Reed's house repeating "don't go too far". When they get back and tell Reed's dad that there was a problem with the car and they didn't know what was wrong. Reed's dad, Dan was pissed.
- It is late in the day and Scott, Reed, Brad and John Fette walk to Bryon's house. Bryon gives them a bottle of Wild Turkey. It's dark out, around 9pm in late summer. The friends are all going to sleep over at Scott's. They are all drinking the whisky out of the bottle except for Scott, who didn't want to drink since he was hosting. They are 1 block away from Scott's house and Brad, Reed and John are very drunk. Scott was walking ahead because everyone was drunk and being annoying. The Hackettstown police station is right in front of them. So, they decide to cut through behind the John Deere dealership so they don't walk right in front of the police station. As they come out the other side, there is a police car on the way home from duty. The cop stops and asks what they boys are doing. Brad immediatly tries to run, but it isn't any more than a walk. Reed just gives up. John vomits on the cop's shoes. Scott stated walking back because he wondering what was taking so long and witnessed the entire event. he was able to retell the story the next day because none of the friends coud remember what happened. In the police station, the officers were questioning the friends. Reed was spilling his life story. Brad couldn't remember his mom's name and kept saying her name was "Amy". Reed was getting upset and saying "Brad, would you just tell them!". the parents eventually picked them up. John Fette ended up gettign grounded for a long time and was not able to hang out with the freinds for months. Brad was in trouble, but only for about a week. Reed's parents thought it was funny they woke him up the next morning by putting a jar of mayonaise under his nose. The police were all laughing about it and the frieinds didnt get in any real trouble.
- Brad drives a VW Karmanghia, which is being repaired more often than it is on the road. It burns oil. And, the one time he lent his car to Reed, he forgot to tell him to check the oil level. So, Reed was drivnig and the engine siezed up. After getting the car towed back to his house. Brad buys a VW bug to put the engine in his Karmanghia. Todd talked him into doing the work himself and said he would help, but is always too busy. Brad is eventually able to get the old engine off. It is in his garage. He drops the engine down, then jacks the car up over the engine, then rolls it out from underneath. When he goes to attach the replacement engine to the transmission, he doesnt have the right type of screwdriver, it needed a screwdriver with one of those star type heads. He does eventually get it attached but, he didn't tighten those screws enough and they sheared off when he tried to drive away. He ended up bringing the car to the repair shop anyway to have the old screws drilled out and retapped. This repair shop constantly rescheduled the work for Brad's car and it took weeks to get it back.

### Characters
Describe the characters you envision. Who are they? What are they like?

- Brad - Main character. The most socially awkward of the group. Mild, undiagnosed autism. Super curious, instigator, loyal, thinks he is athletic. Friedds with Scott and Reed
- Reed - Main Character. Brillant, outgoing, always has girlfriends, sexually active, nerdy but popular
- Scott - Main Character. The most outgoing. defacto leader of the friends. Very smart and talented, not awkward socially. Always needs to be the center of attention.
- Todd - Brad's brother. 1 year and 1 grade older. He's one of the most popular kids in his class. He makes the most dumb choices out of all the characters.
- John Fette - lives in Panther Valley, a gated community. he was adopted from South Korea when he was 7 and he still has a thick accent even though he doesnt know how to speak Korean. John is good natured, great at soccer. When invited out he usually makes lame excuses like "I have to walk the dog". John is on the soccer team with Brad and Scott. He never participates in sleepovers.
- Amy - Brad's sister who is 6 years younger and a typical younger sister with tattletaling and being annoying when friends were over to visit

### Setting
Hackettstown, NJ

### Tone for This Sketch
Mostly funny. Like a Seinfeld, a show about nothing. Like Freaks and Geeks, with awkward characters and stage setting. Like Goldbergs with narration and storytelling.

---

## What I'm Hoping For (Optional)

- NA

---

## What to Avoid (Optional)

- NA

---

## Additional Notes (Optional)

- NA

---

## Inspiration References (Optional)

- NA

---

**STATUS:** 
- Currently in draft mode