# Show Bible: That 80s Show

This document defines the creative guidelines for your show. Fill in each section to help the writing system understand your show's identity, tone, and rules.

---

## Show Identity

### Show Name
That 80s Show

### What's This Show About?
A group of high school aged teenagers growing up 1984-1988. The group of friends are constantly making bad decisions. But, they always seem to end up okay in the end.

### Target Audience
People who grew up in the 1980s. People who like "Freaks and Geeks"

### Show Personality

- whimsical and quirky
- Nostalgic and Sentimental
- mockumentary
- Character-driven
- serialized

---

## Tone & Style

### Overall Tone
Quirky commedy

### Comedy Styles We Embrace

#### Style 1: Homevideo
**Description:** Mocumentary comedy
**Example:** The Office, Parks and Rec
**Why it works:** It should feel like the charachters are making homemade videos of each other in action

#### Style 2: Its a show about nothing
**Description:** anecdotal comedy
**Example:** Seinfeld, Everybody Loves Raymond
**Why it works:** These are short stories based on real events that don't really feed a larger story


### Comedy Styles We Avoid

- NA

---

## Content Guidelines

### Topics We Love
failures with girls, bad decisions, teen drinking, low budget activities

- failures with girls - the boys are always talking about girls and all but Reed are too shy to take action
- Bad decisions - its what the show is about, the great stories that come from doing stupid stuff
- teen drinking - most bad decisions are born from loose inhabitions
- low budget activities - teenagers rarely have money, so hanging out at someone's house, camping, or just cruising around are staple activities
- 1980s technology - Reed and Brad are consumate computer nerds with Brad's commodore 64, they play Ultima 3. Reed bought the Amiga, the most powerful computer of the time.

### Topics We Avoid
- NA

### Content Boundaries

#### Language
no limits. use the terms from the 80s that boys would say.

#### Violence
minimum. an after school fight is ok, but it should have heavvy comic tones, like the movine "3 O'Clock High". Minor car accidents with no injuries. Or, the one time that Scott had a party and Mark Edgerton took the trash. Mark threw the trash in someone's yard. The homeowner called the police. The police found some old mail with Scott's address. Then, Scott told the police that Mark took the trash. Later that day, Mark called scott to apologize and Mark's dad was beating him while he was on the phone with scott.

#### Sexual Content
Primarily innuendo. The boys will share their exploits and experiences with eachother, but it is usually just the funny parts and failed attempts, not graphic.

#### Sensitive Topics
domestic violence

---

## Reference Points

### Sketches/Shows We Love (Inspiration)

#### The Office
**Why we love it:** The filming style and the character building
**What we learn from it:** The cameraman should always be one of the friends, family or acquaintenance. But, usually a different person for each episode.

#### Seinfeld
**Why we love it:** Each episode is based on a simple idea that has a lot of funny interactions built around it. And, every episode is different.
**What we learn from it:** There doesnt need to be an underlying storyline. Each episode can be taken for face value and stand on it's own funny concepts and interactions.

#### Freaks and Geeks
**Why we love it:** The time period, the nostalgic feel, and the geeks all resonate with us.
**What we learn from it:** In the 1980s, just hanging out together could be an eventful day or night. We didn't depend on technology.


### What's NOT Us
- NA

---

## Character Types That Work

- NA

### The Nerd
Socially awkward, intellectual, and often obsessed with niche interests. This is the main theme of the friend group.

### Awkward Teenager
Unconventional, quirky, and acts according to their own internal logic. Most of the bad decisions on the show are born from lack of logical thinking.

### Inexperienced ambition
Creating comedy through ineptitude. When the teens aren't being lazy, they try to do things that they don't understand and they usually learn the hardway through mistakes and miscues.

### Wisecracking Teen
Witty, sarcastic, and uses humor to shield emotions. These are the traits that help the boys feel normal despite all their awkwardness.

---

## Sketch Preferences

### Target Length
15-20 minutes

### Structural Preferences
Cold open, 2 acts and tag. Resets and callbacks throughout. The status quo gets restored and broken through the episode.

### Ending Style
Emptying the Space: The characters leave the iconic set for the last time, often showing an empty room, emphasizing nostalgia.

---

## Quick Reference Checklist

Use this to evaluate if a sketch fits your show:

- [ ] Matches our tone? [Your tone description]
- [ ] Uses our comedy styles?
- [ ] Avoids our no-go topics?
- [ ] Features character types that work for us?
- [ ] Right length?
- [ ] Ending lands?

---

## Notes & Evolution

- NA

---

**Last Updated:** [Date]
